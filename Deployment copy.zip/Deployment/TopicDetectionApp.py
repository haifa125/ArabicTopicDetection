from flask import Flask,render_template,url_for,request
import pandas as pd 
import pickle
from sklearn.feature_extraction.text import CountVectorizer,TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split as split
from sklearn.svm import LinearSVC
import gensim
import spacy
import numpy as np
import re
import string


#from sklearn.externals import joblib


app = Flask(__name__)

# 2
emoji_pattern = re.compile("["
    "\U0001F1E0-\U0001F1FF"  # flags (iOS)
    "\U0001F300-\U0001F5FF"  # symbols & pictographs
    "\U0001F600-\U0001F64F"  # emoticons
    "\U0001F680-\U0001F6FF"  # transport & map symbols
    "\U0001F700-\U0001F77F"  # alchemical symbols
    "\U0001F780-\U0001F7FF"  # Geometric Shapes Extended
    "\U0001F800-\U0001F8FF"  # Supplemental Arrows-C
    "\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs
    "\U0001FA00-\U0001FA6F"  # Chess Symbols
    "\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A
    "\U00002702-\U000027B0"  # Dingbats
    "\U000024C2-\U0001F251" 
    "]+" , flags=re.UNICODE)

arabic_diacritics = re.compile("""
                             ّ    | # Tashdid
                             َ    | # Fatha
                             ً    | # Tanwin Fath
                             ُ    | # Damma
                             ٌ    | # Tanwin Damm
                             ِ    | # Kasra
                             ٍ    | # Tanwin Kasr
                             ْ    | # Sukun
                             ـ     # Tatwil/Kashida

                         """, re.VERBOSE)
def clean(text): 
    
    #Remove URLs
    text = re.sub('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F]))+', ' ', text)
    
    #Remove emails
    text = re.sub('^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$', '', text)
    
    #Remove mentions (if any)
    text = re.sub('@[A-Za-z0–9]+', ' ', text)
    
    #Remove emojis
    text = re.sub(emoji_pattern, "", text)
    
    #Remove emoji encodings
    text = re.sub('emoji[0-9][0-9][0-9]', '', text) 
    
    #Remove Arabic diacritics
    text = re.sub(arabic_diacritics, '', text)

    #Remove English letters 
    if re.match("#(\w+)",text) == None: 
        text = re.sub("[A-Za-z]", "", text)
        
    #Translate numbers from English to Arabic 
    text = re.sub("0", "٠", text)
    text = re.sub("1", "١", text)
    text = re.sub("2", "٢", text)
    text = re.sub("3", "٣", text)
    text = re.sub("4", "٤", text)
    text = re.sub("5", "٥", text)
    text = re.sub("6", "٦", text)
    text = re.sub("7", "٧", text)
    text = re.sub("8", "٨", text)
    text = re.sub("9", "٩", text)
        
    text = re.sub("[إأٱآا]", "ا", text)
    text = re.sub("ة", "ه", text)
    text = re.sub("[يى]", "ي", text)
    text = re.sub("[ئؤ]", "ء", text)
    
    text = re.sub("[«»،؟,ـ]", "", text)
    
    exclude1 = set(string.punctuation+'؟،٪؛') 
    exclude2 = set(string.punctuation+ '١٢٣٤٥٦٧٨٩٠؟،٪؛')
    text = ''.join(ch for ch in text if ch not in exclude1) 
    text = ''.join(ch for ch in text if ch not in exclude2) 
    
    return(text)
    
model = gensim.models.Word2Vec.load("../Resources/AraVec/full_uni_cbow_100_wiki.mdl")
print("We've",len(model.wv.index2word),"vocabularies") 

nlp = spacy.load("spacy.aravec.model/")

# Define the preprocessing Class
class Preprocessor:
    def __init__(self, tokenizer, **cfg):
        self.tokenizer = tokenizer

    def __call__(self, text):
        preprocessed = clean(text)
        return self.tokenizer(preprocessed)
    
nlp.tokenizer = Preprocessor(nlp.tokenizer)


    
@app.route('/')
def home():
	return render_template('home.html')

@app.route('/predict',methods=['POST'])
def predict():
    
    version1_Data = pd.read_csv("version1.csv", encoding="utf-16")
        
    label1 = version1_Data['topic']
    
    version1_Data.fillna("")
    
    label_map = {
    'Art' : 0,
    'Economy' : 1,
    'Health' : 2,
    'Law' : 3,
    'Literature':4,
    'Politics':5,
    'Religion':6,
    'Sport':7,
    'Technology':8}
    
    y_enc1 = label1.apply(lambda x: label_map[x])
    
    
    x1 = np.array([nlp(d).vector for d in version1_Data["text"].astype("str")])
    
    y1 = np.array([d for d in y_enc1])
        
    X_train1,X_test1,y_train1,y_test1 = split(x1,y1, test_size = 0.2, random_state = 10)
     
    print(y_train1)
    
    svm1 = LinearSVC().fit(X_train1,y_train1)
    
    if request.method == 'POST':
        message = request.form['message']
        text = [message]
        data = np.array([nlp(d).vector for d in text])
        #vect = cv.transform(data).toarray()
        my_prediction = svm1.predict(data)
        return render_template('result.html',prediction = my_prediction)


if __name__ == '__main__':
	app.run(debug=True)
